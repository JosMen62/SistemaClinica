/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.dao;

import com.integrador.config.ConexionMySQL;
import com.integrador.modelo.Paciente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
    private Connection cn = ConexionMySQL.getInstancia().getConexion();

    public List<Paciente> listar() throws Exception {
        List<Paciente> lista = new ArrayList<>();
        String sql = "SELECT * FROM paciente WHERE estado = TRUE ORDER BY apellidos";
        try (Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public Paciente buscarPorDni(String dni) throws Exception {
        String sql = "SELECT * FROM paciente WHERE dni = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, dni);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        }
        return null;
    }

    public void crear(Paciente p) throws Exception {
        String sql = "INSERT INTO paciente(dni, nombres, apellidos, fecha_nacimiento, telefono, email, direccion) VALUES(?,?,?,?,?,?,?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getDni());
            ps.setString(2, p.getNombres());
            ps.setString(3, p.getApellidos());
            ps.setDate(4, Date.valueOf(p.getFechaNacimiento()));
            ps.setString(5, p.getTelefono());
            ps.setString(6, p.getEmail());
            ps.setString(7, p.getDireccion());
            ps.executeUpdate();
        }
    }

    public void actualizar(Paciente p) throws Exception {
        String sql = "UPDATE paciente SET nombres=?, apellidos=?, fecha_nacimiento=?, telefono=?, email=?, direccion=? WHERE dni=?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, p.getNombres());
            ps.setString(2, p.getApellidos());
            ps.setDate(3, Date.valueOf(p.getFechaNacimiento()));
            ps.setString(4, p.getTelefono());
            ps.setString(5, p.getEmail());
            ps.setString(6, p.getDireccion());
            ps.setString(7, p.getDni());
            ps.executeUpdate();
        }
    }

    public void eliminar(String dni) throws Exception {
        String sql = "UPDATE paciente SET estado = FALSE WHERE dni = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, dni);
            ps.executeUpdate();
        }
    }

    private Paciente mapear(ResultSet rs) throws SQLException {
        Paciente p = new Paciente();
        p.setDni(rs.getString("dni"));
        p.setNombres(rs.getString("nombres"));
        p.setApellidos(rs.getString("apellidos"));
        p.setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
        p.setTelefono(rs.getString("telefono"));
        p.setEmail(rs.getString("email"));
        p.setDireccion(rs.getString("direccion"));
        p.setEstado(rs.getBoolean("estado"));
        return p;
    }
}

