/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.dao;

import com.integrador.config.ConexionMySQL;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.integrador.modelo.Usuario;

/**
 *
 * @author jose2
 */
public class UsuarioDAO {
    private Connection cn = ConexionMySQL.getInstancia().getConexion();

    public Usuario buscarPorUsername(String username) throws Exception {
        String sql = "SELECT * FROM usuario WHERE username = ? AND estado = TRUE";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id_usuario"));
                u.setUsername(rs.getString("username"));
                u.setPasswordHash(rs.getString("password_hash"));
                u.setRol(rs.getString("rol"));
                u.setEstado(rs.getBoolean("estado"));
                return u;
            }
        }
        return null;
    }
}
