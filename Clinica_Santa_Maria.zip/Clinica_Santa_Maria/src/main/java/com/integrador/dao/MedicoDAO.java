/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.dao;

import com.integrador.config.ConexionMySQL;
import com.integrador.modelo.Especialidad;
import com.integrador.modelo.Medico;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class MedicoDAO {
     private Connection cn = ConexionMySQL.getInstancia().getConexion();

    public List<Medico> listar() throws Exception {
        List<Medico> lista = new ArrayList<>();
        String sql = "SELECT m.*, e.nombre as esp_nombre, e.id_especialidad FROM medico m INNER JOIN especialidad e ON m.id_especialidad = e.id_especialidad WHERE m.estado = TRUE";
        try (Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public Medico buscarPorCMP(String cmp) throws Exception {
        String sql = "SELECT m.*, e.nombre as esp_nombre, e.id_especialidad FROM medico m INNER JOIN especialidad e ON m.id_especialidad = e.id_especialidad WHERE m.cmp = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, cmp);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        }
        return null;
    }

    public void crear(Medico m) throws Exception {
        String sql = "INSERT INTO medico(cmp, nombres, apellidos, telefono, email, id_especialidad) VALUES(?,?,?,?,?,?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, m.getCmp());
            ps.setString(2, m.getNombres());
            ps.setString(3, m.getApellidos());
            ps.setString(4, m.getTelefono());
            ps.setString(5, m.getEmail());
            ps.setInt(6, m.getEspecialidad().getId());
            ps.executeUpdate();
        }
    }

    public void actualizar(Medico m) throws Exception {
        String sql = "UPDATE medico SET nombres=?, apellidos=?, telefono=?, email=?, id_especialidad=? WHERE cmp=?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, m.getNombres());
            ps.setString(2, m.getApellidos());
            ps.setString(3, m.getTelefono());
            ps.setString(4, m.getEmail());
            ps.setInt(5, m.getEspecialidad().getId());
            ps.setString(6, m.getCmp());
            ps.executeUpdate();
        }
    }

    public void eliminar(String cmp) throws Exception {
        String sql = "UPDATE medico SET estado = FALSE WHERE cmp = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, cmp);
            ps.executeUpdate();
        }
    }

    private Medico mapear(ResultSet rs) throws SQLException {
        Medico m = new Medico();
        m.setCmp(rs.getString("cmp"));
        m.setNombres(rs.getString("nombres"));
        m.setApellidos(rs.getString("apellidos"));
        m.setTelefono(rs.getString("telefono"));
        m.setEmail(rs.getString("email"));
        m.setEstado(rs.getBoolean("estado"));
        Especialidad e = new Especialidad();
        e.setId(rs.getInt("id_especialidad"));
        e.setNombre(rs.getString("esp_nombre"));
        m.setEspecialidad(e);
        return m;
    }
}

