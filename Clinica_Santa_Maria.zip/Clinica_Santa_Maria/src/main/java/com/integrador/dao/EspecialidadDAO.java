/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.dao;

import com.integrador.config.ConexionMySQL;
import com.integrador.modelo.Especialidad;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class EspecialidadDAO {
    private Connection cn = ConexionMySQL.getInstancia().getConexion();

    public List<Especialidad> listar() throws Exception {
        List<Especialidad> lista = new ArrayList<>();
        String sql = "SELECT * FROM especialidad WHERE estado = TRUE ORDER BY nombre";
        try (Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Especialidad e = new Especialidad();
                e.setId(rs.getInt("id_especialidad"));
                e.setNombre(rs.getString("nombre"));
                e.setDescripcion(rs.getString("descripcion"));
                e.setEstado(rs.getBoolean("estado"));
                lista.add(e);
            }
        }
        return lista;
    }

    public void crear(Especialidad e) throws Exception {
        String sql = "INSERT INTO especialidad(nombre, descripcion, estado) VALUES(?, ?, TRUE)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getDescripcion());
            ps.executeUpdate();
        }
    }

    public void actualizar(Especialidad e) throws Exception {
        String sql = "UPDATE especialidad SET nombre=?, descripcion=? WHERE id_especialidad=?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getDescripcion());
            ps.setInt(3, e.getId());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws Exception {
        String sql = "UPDATE especialidad SET estado = FALSE WHERE id_especialidad = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
