/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.dao;

import com.integrador.config.ConexionMySQL;
import com.integrador.modelo.Horario;
import com.integrador.modelo.Medico;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class HorarioDAO {
    private Connection cn = ConexionMySQL.getInstancia().getConexion();

    public List<Horario> listar() throws Exception {
        List<Horario> lista = new ArrayList<>();
        String sql = "SELECT h.*, m.nombres, m.apellidos FROM horario h INNER JOIN medico m ON h.cmp_medico = m.cmp WHERE h.estado = TRUE";
        try (Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public void crear(Horario h) throws Exception {
        String sql = "INSERT INTO horario(cmp_medico, dia_semana, hora_inicio, hora_fin, duracion_cita, capacidad_maxima) VALUES(?,?,?,?,?,?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, h.getMedico().getCmp());
            ps.setString(2, h.getDiaSemana());
            ps.setTime(3, Time.valueOf(h.getHoraInicio()));
            ps.setTime(4, Time.valueOf(h.getHoraFin()));
            ps.setInt(5, h.getDuracionCita());
            ps.setInt(6, h.getCapacidadMaxima());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws Exception {
        String sql = "UPDATE horario SET estado = FALSE WHERE id_horario = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Horario mapear(ResultSet rs) throws SQLException {
        Horario h = new Horario();
        h.setId(rs.getInt("id_horario"));
        h.setDiaSemana(rs.getString("dia_semana"));
        h.setHoraInicio(rs.getTime("hora_inicio").toLocalTime());
        h.setHoraFin(rs.getTime("hora_fin").toLocalTime());
        h.setDuracionCita(rs.getInt("duracion_cita"));
        h.setCapacidadMaxima(rs.getInt("capacidad_maxima"));
        h.setEstado(rs.getBoolean("estado"));
        Medico m = new Medico();
        m.setCmp(rs.getString("cmp_medico"));
        m.setNombres(rs.getString("nombres"));
        m.setApellidos(rs.getString("apellidos"));
        h.setMedico(m);
        return h;
    }
}

