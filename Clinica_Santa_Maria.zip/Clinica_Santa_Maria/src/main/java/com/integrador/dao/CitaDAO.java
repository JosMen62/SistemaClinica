/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.dao;

import com.integrador.config.ConexionMySQL;
import com.integrador.modelo.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
public class CitaDAO {
    private Connection cn = ConexionMySQL.getInstancia().getConexion();

    public boolean existeDuplicidad(String cmpMedico, LocalDate fecha, LocalTime hora) throws Exception {
        String sql = "SELECT COUNT(*) FROM cita WHERE cmp_medico = ? AND fecha = ? AND hora = ? AND estado <> 'CANCELADA'";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, cmpMedico);
            ps.setDate(2, Date.valueOf(fecha));
            ps.setTime(3, Time.valueOf(hora));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        }
        return false;
    }

    public List<Cita> listar() throws Exception {
        List<Cita> lista = new ArrayList<>();
        String sql = "SELECT c.*, p.dni as pac_dni, p.nombres as pac_nombres, p.apellidos as pac_apellidos, m.cmp as med_cmp, m.nombres as med_nombres, m.apellidos as med_apellidos, e.nombre as esp_nombre FROM cita c INNER JOIN paciente p ON c.dni_paciente = p.dni INNER JOIN medico m ON c.cmp_medico = m.cmp INNER JOIN especialidad e ON c.id_especialidad = e.id_especialidad WHERE c.estado <> 'CANCELADA' ORDER BY c.fecha, c.hora";
        try (Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapearCompleta(rs));
        }
        return lista;
    }

    public void crear(Cita c) throws Exception {
        String sql = "INSERT INTO cita(dni_paciente, cmp_medico, id_especialidad, fecha, hora, observaciones) VALUES(?,?,?,?,?,?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, c.getPaciente().getDni());
            ps.setString(2, c.getMedico().getCmp());
            ps.setInt(3, c.getEspecialidad().getId());
            ps.setDate(4, Date.valueOf(c.getFecha()));
            ps.setTime(5, Time.valueOf(c.getHora()));
            ps.setString(6, c.getObservaciones());
            ps.executeUpdate();
        }
    }

    public void cancelar(int id) throws Exception {
        String sql = "UPDATE cita SET estado = 'CANCELADA' WHERE id_cita = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Cita> consultarPorFecha(LocalDate fecha) throws Exception {
        List<Cita> lista = new ArrayList<>();
        String sql = "SELECT * FROM cita WHERE fecha = ? AND estado <> 'CANCELADA' ORDER BY hora";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(fecha));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    private Cita mapear(ResultSet rs) throws SQLException {
        Cita c = new Cita();
        c.setId(rs.getInt("id_cita"));
        c.setFecha(rs.getDate("fecha").toLocalDate());
        c.setHora(rs.getTime("hora").toLocalTime());
        c.setEstado(rs.getString("estado"));
        c.setObservaciones(rs.getString("observaciones"));
        return c;
    }

    private Cita mapearCompleta(ResultSet rs) throws SQLException {
        Cita c = mapear(rs);
        Paciente p = new Paciente();
        p.setDni(rs.getString("pac_dni"));
        p.setNombres(rs.getString("pac_nombres"));
        p.setApellidos(rs.getString("pac_apellidos"));
        c.setPaciente(p);
        Medico m = new Medico();
        m.setCmp(rs.getString("med_cmp"));
        m.setNombres(rs.getString("med_nombres"));
        m.setApellidos(rs.getString("med_apellidos"));
        c.setMedico(m);
        Especialidad e = new Especialidad();
        e.setId(rs.getInt("id_especialidad"));
        e.setNombre(rs.getString("esp_nombre"));
        c.setEspecialidad(e);
        return c;
    }
}


