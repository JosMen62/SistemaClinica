package com.integrador.Vista;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PacienteView extends JFrame {

    private final JTextField txtDni = new JTextField(20);
    private final JTextField txtNombres = new JTextField(20);
    private final JTextField txtApellidos = new JTextField(20);
    private final JTextField txtTelefono = new JTextField(20);
    private final JTextField txtEmail = new JTextField(20);
    private final JTextField txtDireccion = new JTextField(20);
    private final JTextField txtBuscar = new JTextField(20);
    private final JDateChooser dateNacimiento = new JDateChooser();
    private final JLabel lblTotal = Estilo.etiqueta("Total de pacientes: 0");
    private final DefaultTableModel modelo = Estilo.modelo("DNI", "Nombres", "Apellidos", "Teléfono", "Email");
    private final JTable tblPacientes = Estilo.tabla(modelo);
    private final JButton btnGuardar = Estilo.boton("Guardar");
    private final JButton btnEditar = Estilo.boton("Editar");
    private final JButton btnEliminar = Estilo.boton("Eliminar");
    private final JButton btnLimpiar = Estilo.boton("Limpiar");
    private final JButton btnBuscar = Estilo.boton("Buscar");

    public PacienteView() {
        Estilo.configurarVentana(this, "Gestión de Pacientes", 860, 700);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        dateNacimiento.setDateFormatString("dd/MM/yyyy");
        add(crearFormulario(), BorderLayout.NORTH);
        add(crearTabla(), BorderLayout.CENTER);
        add(lblTotal, BorderLayout.SOUTH);
    }

    private JPanel crearFormulario() {
        JPanel f = Estilo.formulario("DATOS DEL PACIENTE");
        Estilo.campo(f, 0, "DNI:", txtDni);
        Estilo.campo(f, 1, "Nombres:", txtNombres);
        Estilo.campo(f, 2, "Apellidos:", txtApellidos);
        Estilo.campo(f, 3, "F. Nacimiento:", dateNacimiento);
        Estilo.campo(f, 4, "Teléfono:", txtTelefono);
        Estilo.campo(f, 5, "Email:", txtEmail);
        Estilo.campo(f, 6, "Dirección:", txtDireccion);
        Estilo.ancho(f, 7, Estilo.panelBotones(btnGuardar, btnEditar, btnEliminar, btnLimpiar));
        return f;
    }

    private JPanel crearTabla() {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setOpaque(false);
        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        busqueda.setOpaque(false);
        busqueda.add(Estilo.etiqueta("Buscar por DNI:"));
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);
        p.add(busqueda, BorderLayout.NORTH);
        p.add(new JScrollPane(tblPacientes), BorderLayout.CENTER);
        return p;
    }

    // GETTERS
    public JTextField getTxtDni() { return txtDni; }
    public JTextField getTxtNombres() { return txtNombres; }
    public JTextField getTxtApellidos() { return txtApellidos; }
    public JTextField getTxtTelefono() { return txtTelefono; }
    public JTextField getTxtEmail() { return txtEmail; }
    public JTextField getTxtDireccion() { return txtDireccion; }
    public JTextField getTxtBuscar() { return txtBuscar; }
    public JDateChooser getDateNacimiento() { return dateNacimiento; }
    public JTable getTblPacientes() { return tblPacientes; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnEditar() { return btnEditar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnLimpiar() { return btnLimpiar; }
    public JButton getBtnBuscar() { return btnBuscar; }

    public void limpiarFormulario() {
        txtDni.setText(""); txtNombres.setText(""); txtApellidos.setText("");
        txtTelefono.setText(""); txtEmail.setText(""); txtDireccion.setText("");
        txtBuscar.setText(""); dateNacimiento.setDate(null);
        tblPacientes.clearSelection();
        txtDni.requestFocus();
    }

    public void actualizarTotal(int n) { lblTotal.setText("Total de pacientes: " + n); }
    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
    public boolean confirmar(String msg) { return Estilo.confirmar(this, msg); }
}
