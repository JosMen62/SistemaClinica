package com.integrador.Vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class LoginView extends JFrame {

    private final JTextField txtUsuario = new JTextField(18);
    private final JPasswordField txtPassword = new JPasswordField(18);
    private final JButton btnIngresar = Estilo.boton("INGRESAR");
    private final JButton btnSalir = Estilo.boton("SALIR");

    public LoginView() {
        Estilo.configurarVentana(this, "Clínica Santa María - Inicio de sesión", 740, 430);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());
        add(crearLateral(), BorderLayout.WEST);
        add(crearFormulario(), BorderLayout.CENTER);
        txtUsuario.addActionListener(e -> txtPassword.requestFocus());
        txtPassword.addActionListener(e -> btnIngresar.doClick());
    }

    private JPanel crearLateral() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Estilo.AZUL);
        p.setPreferredSize(new Dimension(280, 0));

        JLabel nombre = new JLabel("<html><div style='text-align:center'>CLÍNICA<br>SANTA MARÍA</div></html>",
                SwingConstants.CENTER);
        nombre.setFont(new Font("Segoe UI", Font.BOLD, 28));
        nombre.setForeground(Color.WHITE);

        JLabel lema = new JLabel("Sistema de gestión de citas", SwingConstants.CENTER);
        lema.setFont(Estilo.NORMAL);
        lema.setForeground(new Color(200, 225, 240));

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridy = 0;
        g.insets = new Insets(0, 0, 10, 0);
        p.add(nombre, g);
        g.gridy = 1;
        p.add(lema, g);
        return p;
    }

    private JPanel crearFormulario() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(4, 30, 4, 30);

        g.gridy = 0;
        JLabel t = Estilo.titulo("Iniciar sesión");
        t.setBorder(BorderFactory.createEmptyBorder(0, 0, 14, 0));
        p.add(t, g);

        g.gridy = 1;
        p.add(Estilo.etiqueta("Usuario"), g);
        g.gridy = 2;
        p.add(txtUsuario, g);

        g.gridy = 3;
        g.insets = new Insets(14, 30, 4, 30);
        p.add(Estilo.etiqueta("Contraseña"), g);
        g.gridy = 4;
        g.insets = new Insets(4, 30, 4, 30);
        p.add(txtPassword, g);

        g.gridy = 5;
        g.insets = new Insets(20, 30, 4, 30);
        p.add(Estilo.panelBotones(btnIngresar, btnSalir), g);

        g.gridy = 6;
        g.insets = new Insets(14, 30, 4, 30);
        JLabel version = Estilo.etiqueta("v1.0 - © 2026");
        version.setForeground(Estilo.GRIS);
        p.add(version, g);
        return p;
    }

    // GETTERS (los usa el Controller)
    public JTextField getTxtUsuario() { return txtUsuario; }
    public JPasswordField getTxtPassword() { return txtPassword; }
    public JButton getBtnIngresar() { return btnIngresar; }
    public JButton getBtnSalir() { return btnSalir; }

    public void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
