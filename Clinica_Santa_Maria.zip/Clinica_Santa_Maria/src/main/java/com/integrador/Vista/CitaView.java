package com.integrador.Vista;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CitaView extends JFrame {

    private final JComboBox<String> cmbPaciente = new JComboBox<>();
    private final JComboBox<String> cmbMedico = new JComboBox<>();
    private final JComboBox<String> cmbEspecialidad = new JComboBox<>();
    private final JDateChooser dateFecha = new JDateChooser();
    private final JTextField txtHora = new JTextField(10);
    private final JTextArea txtObservaciones = new JTextArea(3, 30);
    private final JLabel lblTotal = Estilo.etiqueta("Total de citas: 0");
    private final DefaultTableModel modelo = Estilo.modelo(
            "ID", "Paciente", "Médico", "Especialidad", "Fecha", "Hora", "Estado");
    private final JTable tblCitas = Estilo.tabla(modelo);
    private final JButton btnRegistrar = Estilo.boton("Registrar cita");
    private final JButton btnCancelar = Estilo.boton("Cancelar cita");
    private final JButton btnBuscar = Estilo.boton("Buscar por fecha");
    private final JButton btnTodas = Estilo.boton("Ver todas", Estilo.GRIS);

    public CitaView() {
        Estilo.configurarVentana(this, "Registro de Cita Médica", 980, 740);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        dateFecha.setDateFormatString("dd/MM/yyyy");
        txtObservaciones.setLineWrap(true);
        txtObservaciones.setWrapStyleWord(true);
        add(crearFormulario(), BorderLayout.NORTH);
        add(new JScrollPane(tblCitas), BorderLayout.CENTER);
        add(lblTotal, BorderLayout.SOUTH);
    }

    private JPanel crearFormulario() {
        JPanel f = Estilo.formulario("REGISTRO DE CITA");
        Estilo.campo(f, 0, "Paciente:", cmbPaciente);
        Estilo.campo(f, 1, "Especialidad:", cmbEspecialidad);
        Estilo.campo(f, 2, "Médico:", cmbMedico);
        Estilo.campo(f, 3, "Fecha:", dateFecha);
        Estilo.campo(f, 4, "Hora (HH:mm):", txtHora);
        Estilo.campo(f, 5, "Observaciones:", new JScrollPane(txtObservaciones));
        JPanel botones = Estilo.panelBotones(btnRegistrar, btnCancelar, btnBuscar, btnTodas);
        Estilo.ancho(f, 6, botones);
        return f;
    }

    public JComboBox<String> getCmbPaciente() { return cmbPaciente; }
    public JComboBox<String> getCmbMedico() { return cmbMedico; }
    public JComboBox<String> getCmbEspecialidad() { return cmbEspecialidad; }
    public JDateChooser getDateFecha() { return dateFecha; }
    public JTextField getTxtHora() { return txtHora; }
    public JTextArea getTxtObservaciones() { return txtObservaciones; }
    public JTable getTblCitas() { return tblCitas; }
    public JButton getBtnRegistrar() { return btnRegistrar; }
    public JButton getBtnCancelar() { return btnCancelar; }
    public JButton getBtnBuscar() { return btnBuscar; }
    public JButton getBtnTodas() { return btnTodas; }

    public void limpiarFormulario() {
        txtHora.setText("");
        txtObservaciones.setText("");
        dateFecha.setDate(null);
        if (cmbPaciente.getItemCount() > 0) cmbPaciente.setSelectedIndex(0);
        if (cmbMedico.getItemCount() > 0) cmbMedico.setSelectedIndex(0);
    }

    public void actualizarTotal(int n) { lblTotal.setText("Total de citas: " + n); }
    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
    public boolean confirmar(String msg) { return Estilo.confirmar(this, msg); }
}
