package com.integrador.Vista;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class HorarioView extends JFrame {

    private final JComboBox<String> cmbMedico = new JComboBox<>();
    private final JComboBox<String> cmbDia = new JComboBox<>(new String[]{"LUN", "MAR", "MIE", "JUE", "VIE", "SAB"});
    private final JTextField txtHoraInicio = new JTextField(10);
    private final JTextField txtHoraFin = new JTextField(10);
    private final JTextField txtDuracion = new JTextField(10);
    private final JTextField txtCapacidad = new JTextField(10);
    private final DefaultTableModel modelo = Estilo.modelo(
            "ID", "Médico", "Día", "Inicio", "Fin", "Duración", "Capacidad", "Total Citas");
    private final JTable tblHorarios = Estilo.tabla(modelo);
    private final JButton btnGuardar = Estilo.boton("Guardar");
    private final JButton btnEliminar = Estilo.boton("Eliminar");

    public HorarioView() {
        Estilo.configurarVentana(this, "Gestión de Horarios", 860, 640);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel f = Estilo.formulario("HORARIO DE ATENCIÓN DEL MÉDICO");
        Estilo.campo(f, 0, "Médico:", cmbMedico);
        Estilo.campo(f, 1, "Día:", cmbDia);
        Estilo.campo(f, 2, "Hora inicio (HH:mm):", txtHoraInicio);
        Estilo.campo(f, 3, "Hora fin (HH:mm):", txtHoraFin);
        Estilo.campo(f, 4, "Duración de cita (min):", txtDuracion);
        Estilo.campo(f, 5, "Capacidad por franja:", txtCapacidad);
        Estilo.ancho(f, 6, Estilo.panelBotones(btnGuardar, btnEliminar));
        add(f, BorderLayout.NORTH);
        add(new JScrollPane(tblHorarios), BorderLayout.CENTER);
    }

    public JComboBox<String> getCmbMedico() { return cmbMedico; }
    public JComboBox<String> getCmbDia() { return cmbDia; }
    public JTextField getTxtHoraInicio() { return txtHoraInicio; }
    public JTextField getTxtHoraFin() { return txtHoraFin; }
    public JTextField getTxtDuracion() { return txtDuracion; }
    public JTextField getTxtCapacidad() { return txtCapacidad; }
    public JTable getTblHorarios() { return tblHorarios; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnEliminar() { return btnEliminar; }

    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
}
