package com.integrador.Vista;

import com.integrador.modelo.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class Dashboard extends JFrame {

    private static final Color NARANJA = new Color(230, 126, 34);
    private static final Color MORADO = new Color(142, 68, 173);

    private final Usuario usuario;
    private final JLabel lblUsuario = Estilo.etiqueta("Usuario: ");
    private final JLabel lblCitasHoy = valor(Estilo.AZUL);
    private final JLabel lblPacientes = valor(Estilo.EXITO);
    private final JLabel lblMedicos = valor(NARANJA);
    private final JLabel lblEspecialidades = valor(MORADO);
    private final DefaultTableModel modCitasHoy = Estilo.modelo("Hora", "Paciente", "Médico", "Especialidad");
    private final JTable tblCitasHoy = Estilo.tabla(modCitasHoy);

    private final JButton btnPacientes = Estilo.boton("Pacientes", Estilo.AZUL);
    private final JButton btnMedicos = Estilo.boton("Médicos", Estilo.AZUL);
    private final JButton btnEspecialidades = Estilo.boton("Especialidades", Estilo.AZUL);
    private final JButton btnCitas = Estilo.boton("Citas", Estilo.AZUL);
    private final JButton btnHorarios = Estilo.boton("Horarios", Estilo.AZUL);
    private final JButton btnDisponibilidad = Estilo.boton("Disponibilidad", Estilo.AZUL);
    private final JButton btnReportes = Estilo.boton("Reportes", Estilo.AZUL);
    private final JButton btnUsuarios = Estilo.boton("Usuarios", Estilo.AZUL);
    private final JButton btnActualizar = Estilo.boton("Actualizar", Estilo.GRIS);
    private final JButton btnCerrarSesion = Estilo.boton("Cerrar sesión", Estilo.PELIGRO);

    public Dashboard(Usuario usuario) {
        this.usuario = usuario;
        Estilo.configurarVentana(this, "Clínica Santa María - Panel principal", 1020, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        add(crearMenu(), BorderLayout.WEST);
        add(crearCentro(), BorderLayout.CENTER);

        JLabel estado = Estilo.etiqueta("  Conectado a MySQL  |  Base de datos: clinica_santa_maria");
        estado.setForeground(Estilo.GRIS);
        estado.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 6));
        add(estado, BorderLayout.SOUTH);
    }

    private static JLabel valor(Color color) {
        JLabel l = new JLabel("0", SwingConstants.CENTER);
        l.setFont(new Font("Segoe UI", Font.BOLD, 34));
        l.setForeground(color);
        return l;
    }

    private JPanel crearMenu() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(Estilo.AZUL_OSCURO);
        menu.setBorder(BorderFactory.createEmptyBorder(20, 14, 16, 14));
        menu.setPreferredSize(new Dimension(210, 0));

        JLabel titulo = new JLabel("MENÚ");
        titulo.setFont(Estilo.TITULO);
        titulo.setForeground(Color.WHITE);
        titulo.setAlignmentX(LEFT_ALIGNMENT);
        menu.add(titulo);
        menu.add(Box.createVerticalStrut(20));

        agregar(menu, btnPacientes);
        agregar(menu, btnMedicos);
        agregar(menu, btnEspecialidades);
        agregar(menu, btnCitas);
        agregar(menu, btnHorarios);
        agregar(menu, btnDisponibilidad);
        agregar(menu, btnReportes);
        if (usuario != null && usuario.esAdministrador()) {
            agregar(menu, btnUsuarios);
        }
        menu.add(Box.createVerticalGlue());
        agregar(menu, btnActualizar);
        agregar(menu, btnCerrarSesion);
        return menu;
    }

    private void agregar(JPanel menu, JButton b) {
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        menu.add(b);
        menu.add(Box.createVerticalStrut(8));
    }

    private JPanel crearCentro() {
        JPanel centro = new JPanel(new BorderLayout(10, 14));
        centro.setOpaque(false);
        centro.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        lblUsuario.setText("Usuario: " + (usuario == null ? "(sin sesión)"
                : usuario.getUsername() + "  (" + usuario.getRol() + ")"));
        JPanel arriba = new JPanel(new GridLayout(3, 1));
        arriba.setOpaque(false);
        arriba.add(Estilo.titulo("Bienvenido al sistema"));
        arriba.add(lblUsuario);
        arriba.add(Estilo.etiqueta("Fecha: " + LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))));

        JPanel tarjetas = new JPanel(new GridLayout(1, 4, 14, 0));
        tarjetas.setOpaque(false);
        tarjetas.add(tarjeta("Citas hoy", lblCitasHoy, Estilo.AZUL));
        tarjetas.add(tarjeta("Pacientes", lblPacientes, Estilo.EXITO));
        tarjetas.add(tarjeta("Médicos", lblMedicos, NARANJA));
        tarjetas.add(tarjeta("Especialidades", lblEspecialidades, MORADO));

        JPanel norte = new JPanel(new BorderLayout(0, 14));
        norte.setOpaque(false);
        norte.add(arriba, BorderLayout.NORTH);
        norte.add(tarjetas, BorderLayout.CENTER);

        JLabel subtitulo = Estilo.etiqueta("CITAS DEL DÍA");
        subtitulo.setFont(Estilo.NEGRITA);
        subtitulo.setForeground(Estilo.AZUL);

        JPanel tabla = new JPanel(new BorderLayout(0, 6));
        tabla.setOpaque(false);
        tabla.add(subtitulo, BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(tblCitasHoy);
        sp.setBorder(BorderFactory.createLineBorder(Estilo.BORDE));
        tabla.add(sp, BorderLayout.CENTER);

        centro.add(norte, BorderLayout.NORTH);
        centro.add(tabla, BorderLayout.CENTER);
        return centro;
    }

    private JPanel tarjeta(String titulo, JLabel valor, Color color) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(5, 0, 0, 0, color),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Estilo.BORDE),
                        BorderFactory.createEmptyBorder(12, 10, 12, 10))));
        JLabel t = Estilo.etiqueta(titulo);
        t.setHorizontalAlignment(SwingConstants.CENTER);
        t.setForeground(Estilo.GRIS);
        p.add(valor, BorderLayout.CENTER);
        p.add(t, BorderLayout.SOUTH);
        return p;
    }

    public void setEstadisticas(int citasHoy, int pacientes, int medicos, int especialidades) {
        lblCitasHoy.setText(String.valueOf(citasHoy));
        lblPacientes.setText(String.valueOf(pacientes));
        lblMedicos.setText(String.valueOf(medicos));
        lblEspecialidades.setText(String.valueOf(especialidades));
    }

    public DefaultTableModel getModCitasHoy() { return modCitasHoy; }
    public JLabel getLblUsuario() { return lblUsuario; }
    public JButton getBtnPacientes() { return btnPacientes; }
    public JButton getBtnMedicos() { return btnMedicos; }
    public JButton getBtnEspecialidades() { return btnEspecialidades; }
    public JButton getBtnCitas() { return btnCitas; }
    public JButton getBtnHorarios() { return btnHorarios; }
    public JButton getBtnDisponibilidad() { return btnDisponibilidad; }
    public JButton getBtnReportes() { return btnReportes; }
    public JButton getBtnUsuarios() { return btnUsuarios; }
    public JButton getBtnActualizar() { return btnActualizar; }
    public JButton getBtnCerrarSesion() { return btnCerrarSesion; }

    public void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public boolean confirmar(String msg) { return Estilo.confirmar(this, msg); }
}
