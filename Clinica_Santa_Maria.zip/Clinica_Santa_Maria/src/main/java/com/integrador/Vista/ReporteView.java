package com.integrador.Vista;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ReporteView extends JFrame {

    private final JDateChooser dateDesde = new JDateChooser();
    private final JDateChooser dateHasta = new JDateChooser();
    private final JComboBox<Object> cmbMedico = new JComboBox<>();
    private final JComboBox<Object> cmbEspecialidad = new JComboBox<>();
    private final JLabel lblTotal = Estilo.etiqueta("Total citas: 0");
    private final JLabel lblProgramadas = Estilo.etiqueta("Programadas: 0");
    private final JLabel lblCanceladas = Estilo.etiqueta("Canceladas: 0");
    private final DefaultTableModel modelo = Estilo.modelo(
            "Fecha", "Hora", "Paciente", "Médico", "Especialidad", "Estado");
    private final JTable tblReporte = Estilo.tabla(modelo);
    private final JButton btnGenerar = Estilo.boton("Generar reporte");
    private final JButton btnImprimir = Estilo.boton("Imprimir", Estilo.GRIS);
    private final JButton btnExportar = Estilo.boton("Exportar a Excel (.csv)", Estilo.EXITO);

    public ReporteView() {
        Estilo.configurarVentana(this, "Generación de Reportes", 960, 680);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        dateDesde.setDateFormatString("dd/MM/yyyy");
        dateHasta.setDateFormatString("dd/MM/yyyy");

        JPanel f = Estilo.formulario("FILTROS - Reporte de citas por rango de fechas");
        Estilo.campo(f, 0, "Desde:", dateDesde);
        Estilo.campo(f, 1, "Hasta:", dateHasta);
        Estilo.campo(f, 2, "Médico (opcional):", cmbMedico);
        Estilo.campo(f, 3, "Especialidad (opcional):", cmbEspecialidad);
        Estilo.ancho(f, 4, Estilo.panelBotones(btnGenerar, btnImprimir, btnExportar));

        JPanel totales = new JPanel(new FlowLayout(FlowLayout.LEFT, 24, 4));
        totales.setOpaque(false);
        totales.add(lblTotal);
        totales.add(lblProgramadas);
        totales.add(lblCanceladas);

        add(f, BorderLayout.NORTH);
        add(new JScrollPane(tblReporte), BorderLayout.CENTER);
        add(totales, BorderLayout.SOUTH);
    }

    public JDateChooser getDateDesde() { return dateDesde; }
    public JDateChooser getDateHasta() { return dateHasta; }
    public JComboBox<Object> getCmbMedico() { return cmbMedico; }
    public JComboBox<Object> getCmbEspecialidad() { return cmbEspecialidad; }
    public JTable getTblReporte() { return tblReporte; }
    public JButton getBtnGenerar() { return btnGenerar; }
    public JButton getBtnImprimir() { return btnImprimir; }
    public JButton getBtnExportar() { return btnExportar; }

    public void setTotales(int total, int programadas, int canceladas) {
        lblTotal.setText("Total citas: " + total);
        lblProgramadas.setText("Programadas: " + programadas);
        lblCanceladas.setText("Canceladas: " + canceladas);
    }

    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
}
