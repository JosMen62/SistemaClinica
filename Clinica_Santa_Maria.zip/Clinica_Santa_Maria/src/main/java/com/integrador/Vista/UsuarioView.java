package com.integrador.Vista;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class UsuarioView extends JFrame {

    private final JTextField txtUsername = new JTextField(20);
    private final JComboBox<String> cmbRol = new JComboBox<>(new String[]{"RECEP", "MEDICO", "ADMIN"});
    private final JPasswordField txtPassword = new JPasswordField(20);
    private final DefaultTableModel modelo = Estilo.modelo("ID", "Usuario", "Rol", "Estado");
    private final JTable tblUsuarios = Estilo.tabla(modelo);
    private final JButton btnGuardar = Estilo.boton("Guardar nuevo");
    private final JButton btnRol = Estilo.boton("Cambiar rol");
    private final JButton btnClave = Estilo.boton("Cambiar contraseña");
    private final JButton btnEstado = Estilo.boton("Activar / Desactivar", Estilo.GRIS);
    private final JButton btnLimpiar = Estilo.boton("Limpiar");

    public UsuarioView() {
        Estilo.configurarVentana(this, "Gestión de Usuarios", 860, 620);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel f = Estilo.formulario("DATOS DEL USUARIO");
        Estilo.campo(f, 0, "Usuario (4-30 caracteres):", txtUsername);
        Estilo.campo(f, 1, "Rol:", cmbRol);
        Estilo.campo(f, 2, "Contraseña (mín. 6):", txtPassword);
        Estilo.ancho(f, 3, Estilo.panelBotones(btnGuardar, btnRol, btnClave, btnEstado, btnLimpiar));
        add(f, BorderLayout.NORTH);
        add(new JScrollPane(tblUsuarios), BorderLayout.CENTER);
    }

    public JTextField getTxtUsername() { return txtUsername; }
    public JComboBox<String> getCmbRol() { return cmbRol; }
    public JPasswordField getTxtPassword() { return txtPassword; }
    public JTable getTblUsuarios() { return tblUsuarios; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnRol() { return btnRol; }
    public JButton getBtnClave() { return btnClave; }
    public JButton getBtnEstado() { return btnEstado; }
    public JButton getBtnLimpiar() { return btnLimpiar; }

    public void limpiarFormulario() {
        txtUsername.setText("");
        txtPassword.setText("");
        cmbRol.setSelectedIndex(0);
        tblUsuarios.clearSelection();
        txtUsername.requestFocus();
    }

    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
}
