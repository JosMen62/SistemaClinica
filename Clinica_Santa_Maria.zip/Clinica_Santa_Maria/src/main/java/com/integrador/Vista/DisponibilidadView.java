package com.integrador.Vista;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class DisponibilidadView extends JFrame {

    private final JComboBox<Object> cmbEspecialidad = new JComboBox<>();
    private final JComboBox<Object> cmbMedico = new JComboBox<>();
    private final JDateChooser dateFecha = new JDateChooser();
    private final JLabel lblTotal = Estilo.etiqueta("Total disponibles: -");
    private final DefaultTableModel modelo = Estilo.modelo("Hora", "Estado", "Detalle");
    private final JTable tblFranjas = Estilo.tabla(modelo);
    private final JButton btnConsultar = Estilo.boton("Consultar");
    private final JButton btnSeleccionar = Estilo.boton("Registrar cita en la franja", Estilo.EXITO);

    public DisponibilidadView() {
        Estilo.configurarVentana(this, "Disponibilidad de Horarios", 800, 640);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        dateFecha.setDateFormatString("dd/MM/yyyy");

        JPanel f = Estilo.formulario("DISPONIBILIDAD DE HORARIOS");
        Estilo.campo(f, 0, "Especialidad:", cmbEspecialidad);
        Estilo.campo(f, 1, "Médico:", cmbMedico);
        Estilo.campo(f, 2, "Fecha:", dateFecha);
        Estilo.ancho(f, 3, Estilo.panelBotones(btnConsultar, btnSeleccionar));

        JPanel pie = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pie.setOpaque(false);
        pie.add(lblTotal);
        pie.add(Estilo.etiqueta("     Verde = disponible  |  Rojo = ocupado"));

        add(f, BorderLayout.NORTH);
        add(new JScrollPane(tblFranjas), BorderLayout.CENTER);
        add(pie, BorderLayout.SOUTH);

        tblFranjas.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean foc, int fila, int col) {
                super.getTableCellRendererComponent(t, v, sel, false, fila, col);
                setHorizontalAlignment(SwingConstants.CENTER);
                setFont(Estilo.NEGRITA);
                if (sel) {
                    setBackground(new Color(204, 229, 243));
                } else {
                    setBackground(fila % 2 == 0 ? Color.WHITE : new Color(244, 248, 252));
                    setForeground("DISPONIBLE".equals(v) ? Estilo.EXITO : Estilo.PELIGRO);
                }
                return this;
            }
        });
    }

    public JComboBox<Object> getCmbEspecialidad() { return cmbEspecialidad; }
    public JComboBox<Object> getCmbMedico() { return cmbMedico; }
    public JDateChooser getDateFecha() { return dateFecha; }
    public JTable getTblFranjas() { return tblFranjas; }
    public JButton getBtnConsultar() { return btnConsultar; }
    public JButton getBtnSeleccionar() { return btnSeleccionar; }
    public void setTotal(String texto) { lblTotal.setText(texto); }

    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
}
