/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.Vista;


import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class Estilo {

    // ---------- Paleta ----------
    public static final Color AZUL = new Color(0, 102, 153);
    public static final Color AZUL_OSCURO = new Color(0, 74, 112);
    public static final Color FONDO = new Color(240, 244, 248);
    public static final Color PELIGRO = new Color(192, 57, 43);
    public static final Color EXITO = new Color(39, 150, 96);
    public static final Color GRIS = new Color(108, 117, 125);
    public static final Color BORDE = new Color(206, 214, 224);
    public static final Color TEXTO = new Color(52, 58, 64);

    public static final Font NORMAL = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font NEGRITA = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font TITULO = new Font("Segoe UI", Font.BOLD, 22);

    private Estilo() {}

    /** Llamar una vez al iniciar el programa (en el main). */
    public static void instalarTema() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // se usa el estilo por defecto
        }
        Enumeration<Object> claves = UIManager.getDefaults().keys();
        while (claves.hasMoreElements()) {
            Object k = claves.nextElement();
            if (UIManager.get(k) instanceof FontUIResource) {
                UIManager.put(k, new FontUIResource(NORMAL));
            }
        }
        javax.swing.border.Border campo = BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDE),
                BorderFactory.createEmptyBorder(5, 7, 5, 7));
        UIManager.put("TextField.border", campo);
        UIManager.put("PasswordField.border", campo);
    }

    // ---------- Ventanas ----------

    public static void configurarVentana(JFrame f, String titulo, int ancho, int alto) {
        f.setTitle(titulo);
        f.setSize(ancho, alto);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.getContentPane().setBackground(FONDO);
    }

    public static JLabel titulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(TITULO);
        l.setForeground(AZUL);
        return l;
    }

    public static JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(NORMAL);
        l.setForeground(TEXTO);
        return l;
    }

    // ---------- Botones ----------

    public static JButton boton(String texto) {
        return boton(texto, colorPara(texto));
    }

    public static JButton boton(String texto, Color color) {
        return new Boton(texto, color);
    }

    private static Color colorPara(String texto) {
        String t = texto.toLowerCase();
        if (t.contains("eliminar") || t.contains("cancelar") || t.contains("desactivar")
                || t.contains("salir") || t.contains("cerrar")) {
            return PELIGRO;
        }
        if (t.contains("nuevo") || t.contains("limpiar") || t.contains("imprimir")) {
            return GRIS;
        }
        if (t.contains("atendida") || t.contains("exportar")) {
            return EXITO;
        }
        return AZUL;
    }

    private static class Boton extends JButton {
        private final Color base;
        private boolean encima = false;

        Boton(String texto, Color base) {
            super(texto);
            this.base = base;
            setFont(NEGRITA);
            setForeground(Color.WHITE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    encima = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    encima = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = base;
            if (!isEnabled()) {
                c = new Color(180, 185, 190);
            } else if (getModel().isPressed()) {
                c = base.darker().darker();
            } else if (encima) {
                c = base.darker();
            }
            g2.setColor(c);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static JPanel panelBotones(JButton... botones) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setOpaque(false);
        for (JButton b : botones) {
            p.add(b);
        }
        return p;
    }

    // ---------- Formularios ----------

    /** Tarjeta blanca con título azul. */
    public static JPanel formulario(String titulo) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setOpaque(true);
        TitledBorder tb = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDE), " " + titulo + " ",
                TitledBorder.LEFT, TitledBorder.TOP, NEGRITA, AZUL);
        p.setBorder(BorderFactory.createCompoundBorder(tb, BorderFactory.createEmptyBorder(6, 6, 6, 6)));
        return p;
    }

    public static void campo(JPanel p, int fila, String texto, JComponent c) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 5, 8);
        g.gridy = fila;
        g.gridx = 0;
        g.anchor = GridBagConstraints.WEST;
        p.add(etiqueta(texto), g);
        g.gridx = 1;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        p.add(c, g);
    }

    /** Agrega un componente ocupando las dos columnas. */
    public static void ancho(JPanel p, int fila, JComponent c) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 4, 8);
        g.gridy = fila;
        g.gridx = 0;
        g.gridwidth = 2;
        g.anchor = GridBagConstraints.WEST;
        p.add(c, g);
    }

    // ---------- Tablas ----------

    public static DefaultTableModel modelo(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
    }

    public static JTable tabla(DefaultTableModel modelo) {
        JTable t = new JTable(modelo);
        t.setFont(NORMAL);
        t.setRowHeight(28);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setShowVerticalLines(false);
        t.setShowHorizontalLines(true);
        t.setGridColor(new Color(228, 233, 240));
        t.setIntercellSpacing(new java.awt.Dimension(0, 1));
        t.setFillsViewportHeight(true);
        t.setDefaultRenderer(Object.class, new Cebra());
        t.getTableHeader().setDefaultRenderer(new Cabecera());
        t.getTableHeader().setReorderingAllowed(false);
        t.getTableHeader().setPreferredSize(new java.awt.Dimension(0, 32));
        return t;
    }

    private static class Cebra extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                       boolean foc, int fila, int col) {
            super.getTableCellRendererComponent(t, v, sel, false, fila, col);
            setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            if (sel) {
                setBackground(new Color(204, 229, 243));
                setForeground(Color.BLACK);
            } else {
                setBackground(fila % 2 == 0 ? Color.WHITE : new Color(244, 248, 252));
                setForeground(TEXTO);
            }
            return this;
        }
    }

    private static class Cabecera extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                       boolean foc, int fila, int col) {
            super.getTableCellRendererComponent(t, v, false, false, fila, col);
            setOpaque(true);
            setBackground(AZUL);
            setForeground(Color.WHITE);
            setFont(NEGRITA);
            setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
            return this;
        }
    }

    // ---------- Mensajes ----------

    public static void error(Component padre, Exception ex) {
        String msg = ex.getMessage() != null ? ex.getMessage() : ex.toString();
        JOptionPane.showMessageDialog(padre, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void info(Component padre, String msg) {
        JOptionPane.showMessageDialog(padre, msg);
    }

    public static boolean confirmar(Component padre, String msg) {
        return JOptionPane.showConfirmDialog(padre, msg, "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}