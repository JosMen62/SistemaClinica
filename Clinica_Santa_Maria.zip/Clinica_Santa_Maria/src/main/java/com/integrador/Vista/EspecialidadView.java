package com.integrador.Vista;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class EspecialidadView extends JFrame {

    private final JTextField txtNombre = new JTextField(25);
    private final JTextField txtDescripcion = new JTextField(25);
    private final DefaultTableModel modelo = Estilo.modelo("ID", "Nombre", "Descripción");
    private final JTable tblEspecialidades = Estilo.tabla(modelo);
    private final JButton btnGuardar = Estilo.boton("Guardar");
    private final JButton btnEditar = Estilo.boton("Editar");
    private final JButton btnEliminar = Estilo.boton("Eliminar");
    private final JButton btnLimpiar = Estilo.boton("Limpiar");

    public EspecialidadView() {
        Estilo.configurarVentana(this, "Gestión de Especialidades", 760, 560);
        setLayout(new BorderLayout(8, 8));
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel f = Estilo.formulario("DATOS DE LA ESPECIALIDAD");
        Estilo.campo(f, 0, "Nombre:", txtNombre);
        Estilo.campo(f, 1, "Descripción:", txtDescripcion);
        Estilo.ancho(f, 2, Estilo.panelBotones(btnGuardar, btnEditar, btnEliminar, btnLimpiar));
        add(f, BorderLayout.NORTH);
        add(new JScrollPane(tblEspecialidades), BorderLayout.CENTER);
    }

    public JTextField getTxtNombre() { return txtNombre; }
    public JTextField getTxtDescripcion() { return txtDescripcion; }
    public JTable getTblEspecialidades() { return tblEspecialidades; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnEditar() { return btnEditar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnLimpiar() { return btnLimpiar; }

    public void limpiarFormulario() {
        txtNombre.setText(""); txtDescripcion.setText("");
        tblEspecialidades.clearSelection();
        txtNombre.requestFocus();
    }

    public void mostrarMensaje(String msg) { Estilo.info(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
    public boolean confirmar(String msg) { return Estilo.confirmar(this, msg); }
}
