/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.Vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MedicoView extends JFrame {
    private JTextField txtCmp, txtNombres, txtApellidos, txtTelefono, txtEmail;
    private JComboBox<String> cmbEspecialidad;
    private JTable tblMedicos;
    private JButton btnGuardar, btnEditar, btnEliminar, btnLimpiar;

    public MedicoView() {
        setTitle("Gestión de Médicos");
        setSize(800, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        txtCmp = new JTextField(12);
        txtNombres = new JTextField(20);
        txtApellidos = new JTextField(20);
        txtTelefono = new JTextField(10);
        txtEmail = new JTextField(20);
        cmbEspecialidad = new JComboBox<>();
        btnGuardar = new JButton("Guardar");
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar");
        tblMedicos = new JTable(new DefaultTableModel(new Object[]{"CMP", "Nombres", "Apellidos", "Especialidad", "Teléfono"}, 0));

        JPanel form = new JPanel(new java.awt.GridLayout(6, 2, 5, 5));
        form.add(new JLabel("CMP:")); form.add(txtCmp);
        form.add(new JLabel("Nombres:")); form.add(txtNombres);
        form.add(new JLabel("Apellidos:")); form.add(txtApellidos);
        form.add(new JLabel("Especialidad:")); form.add(cmbEspecialidad);
        form.add(new JLabel("Teléfono:")); form.add(txtTelefono);
        form.add(new JLabel("Email:")); form.add(txtEmail);

        JPanel botones = new JPanel();
        botones.add(btnGuardar); botones.add(btnEditar); botones.add(btnEliminar); botones.add(btnLimpiar);

        add(form, java.awt.BorderLayout.NORTH);
        add(new JScrollPane(tblMedicos), java.awt.BorderLayout.CENTER);
        add(botones, java.awt.BorderLayout.SOUTH);
    }

    public JTextField getTxtCmp() { return txtCmp; }
    public JTextField getTxtNombres() { return txtNombres; }
    public JTextField getTxtApellidos() { return txtApellidos; }
    public JTextField getTxtTelefono() { return txtTelefono; }
    public JTextField getTxtEmail() { return txtEmail; }
    public JComboBox<String> getCmbEspecialidad() { return cmbEspecialidad; }
    public JTable getTblMedicos() { return tblMedicos; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnEditar() { return btnEditar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnLimpiar() { return btnLimpiar; }

    public void limpiarFormulario() {
        txtCmp.setText(""); txtNombres.setText(""); txtApellidos.setText("");
        txtTelefono.setText(""); txtEmail.setText("");
        cmbEspecialidad.setSelectedIndex(0);
    }

    public void mostrarMensaje(String msg) { JOptionPane.showMessageDialog(this, msg); }
    public void mostrarError(String msg) { JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE); }
}

