/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.util;

import java.util.regex.Pattern;

/**
 *
 * @author jose2
 */
public class Validador {
    private static final Pattern DNI = Pattern.compile("^\\d{8}$");
    private static final Pattern EMAIL = Pattern.compile("^[\\w.-]+@[\\w.-]+\\.[a-z]{2,}$");
    private static final Pattern TEL = Pattern.compile("^\\d{9}$");

    public static boolean validarDNI(String dni) { return dni != null && DNI.matcher(dni).matches(); }
    public static boolean validarEmail(String email) { return email == null || email.isEmpty() || EMAIL.matcher(email).matches(); }
    public static boolean validarTelefono(String tel) { return tel == null || tel.isEmpty() || TEL.matcher(tel).matches(); }
    public static boolean noVacio(String s) { return s != null && !s.trim().isEmpty(); }

    
}
