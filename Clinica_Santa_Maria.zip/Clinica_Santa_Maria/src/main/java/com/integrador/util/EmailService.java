/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.util;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailService {
    private String host, username, password;
    private int port;

    public EmailService(String host, int port, String username, String password) {
        this.host = host; this.port = port; this.username = username; this.password = password;
    }

    public void enviarConfirmacion(String destinatario, String nombrePaciente, String nombreMedico, String especialidad, String fecha, String hora) throws Exception {
        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", String.valueOf(port));
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(username, "Clínica Santa María"));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        msg.setSubject("Confirmación de Cita Médica");
        msg.setContent("<html><body><h2>Clínica Santa María</h2><p>Estimado(a) " + nombrePaciente + ",</p><p>Su cita ha sido registrada:</p><ul><li>Médico: " + nombreMedico + "</li><li>Especialidad: " + especialidad + "</li><li>Fecha: " + fecha + "</li><li>Hora: " + hora + "</li></ul></body></html>", "text/html; charset=utf-8");
        Transport.send(msg);
    }
}



