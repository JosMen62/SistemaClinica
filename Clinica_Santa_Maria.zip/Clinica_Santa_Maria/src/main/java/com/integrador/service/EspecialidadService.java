/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.service;

import com.integrador.dao.EspecialidadDAO;
import com.integrador.modelo.Especialidad;
import java.util.List;


public class EspecialidadService {
    private EspecialidadDAO dao = new EspecialidadDAO();

    public List<Especialidad> listar() throws Exception { return dao.listar(); }

    public void registrar(Especialidad e) throws Exception {
        if (e.getNombre() == null || e.getNombre().trim().isEmpty()) throw new Exception("Nombre obligatorio");
        dao.crear(e);
    }

    public void actualizar(Especialidad e) throws Exception {
        if (e.getNombre() == null || e.getNombre().trim().isEmpty()) throw new Exception("Nombre obligatorio");
        dao.actualizar(e);
    }

    public void eliminar(int id) throws Exception { dao.eliminar(id); }
}
