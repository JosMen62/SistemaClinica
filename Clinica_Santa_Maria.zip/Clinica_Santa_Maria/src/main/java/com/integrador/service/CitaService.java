/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.service;

import com.integrador.dao.CitaDAO;
import com.integrador.modelo.Cita;
import java.time.LocalDate;
import java.util.List;

public class CitaService {
    private CitaDAO dao = new CitaDAO();

    public List<Cita> listar() throws Exception { return dao.listar(); }
    public List<Cita> consultarPorFecha(LocalDate fecha) throws Exception { return dao.consultarPorFecha(fecha); }

    public void registrar(Cita c) throws Exception {
        if (c.getPaciente() == null || c.getPaciente().getDni() == null) throw new Exception("Seleccione paciente");
        if (c.getMedico() == null || c.getMedico().getCmp() == null) throw new Exception("Seleccione médico");
        if (c.getEspecialidad() == null) throw new Exception("Seleccione especialidad");
        if (c.getFecha() == null) throw new Exception("Fecha obligatoria");
        if (c.getFecha().isBefore(LocalDate.now())) throw new Exception("Fecha no puede ser pasada");
        if (c.getHora() == null) throw new Exception("Hora obligatoria");

        if (dao.existeDuplicidad(c.getMedico().getCmp(), c.getFecha(), c.getHora())) {
            throw new Exception("Ya existe una cita para este médico en esa fecha y hora (RF-14)");
        }
        c.setEstado("PROGRAMADA");
        dao.crear(c);
    }

    public void cancelar(int id) throws Exception {
        if (id <= 0) throw new Exception("ID inválido");
        dao.cancelar(id);
    }
}

