/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.service;

import com.integrador.dao.UsuarioDAO;
import com.integrador.modelo.Usuario;
import org.mindrot.jbcrypt.BCrypt;

/**
 *
 * @author jose2
 */
public class UsuarioService {
   private UsuarioDAO dao = new UsuarioDAO();

    public Usuario autenticar(String username, String password) throws Exception {
        if (username == null || username.trim().isEmpty()) throw new Exception("Usuario obligatorio");
        if (password == null || password.trim().isEmpty()) throw new Exception("Contraseña obligatoria");

        Usuario u = dao.buscarPorUsername(username);
        if (u == null) throw new Exception("Credenciales incorrectas");
        if (!u.isEstado()) throw new Exception("Usuario deshabilitado");
        if (!BCrypt.checkpw(password, u.getPasswordHash())) throw new Exception("Credenciales incorrectas");

        return u;
    }
}
