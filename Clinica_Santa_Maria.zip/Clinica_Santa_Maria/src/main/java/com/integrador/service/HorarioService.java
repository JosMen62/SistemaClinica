/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.service;

import com.integrador.dao.HorarioDAO;
import com.integrador.modelo.Horario;
import java.util.List;

public class HorarioService {
    private HorarioDAO dao = new HorarioDAO();

    public List<Horario> listar() throws Exception { return dao.listar(); }

    public void registrar(Horario h) throws Exception {
        if (h.getMedico() == null || h.getMedico().getCmp() == null) throw new Exception("Seleccione médico");
        if (h.getHoraFin().isBefore(h.getHoraInicio())) throw new Exception("Hora fin debe ser mayor");
        if (h.getDuracionCita() <= 0) throw new Exception("Duración debe ser > 0");
        if (h.getCapacidadMaxima() <= 0) throw new Exception("Capacidad debe ser > 0");
        int d = h.getDuracionCita();
        if (d != 15 && d != 30 && d != 45 && d != 60) throw new Exception("Duración debe ser 15, 30, 45 o 60 min");
        dao.crear(h);
    }

    public void eliminar(int id) throws Exception { dao.eliminar(id); }

}

