/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.service;

import com.integrador.dao.MedicoDAO;
import com.integrador.modelo.Medico;
import com.integrador.util.Validador;
import java.util.List;
import java.util.regex.Pattern;

public class MedicoService {

    private MedicoDAO dao = new MedicoDAO();
    private static final Pattern CMP = Pattern.compile("^CMP-\\d{5}$");

    public List<Medico> listar() throws Exception { return dao.listar(); }
    public Medico buscarPorCMP(String cmp) throws Exception { return dao.buscarPorCMP(cmp); }

    public void registrar(Medico m) throws Exception {
        if (!CMP.matcher(m.getCmp()).matches()) throw new Exception("CMP inválido (formato CMP-12345)");
        if (!Validador.noVacio(m.getNombres())) throw new Exception("Nombres obligatorios");
        if (m.getEspecialidad() == null || m.getEspecialidad().getId() <= 0) throw new Exception("Seleccione especialidad");
        if (dao.buscarPorCMP(m.getCmp()) != null) throw new Exception("Ya existe médico con ese CMP");
        dao.crear(m);
    }

    public void actualizar(Medico m) throws Exception { dao.actualizar(m); }
    public void eliminar(String cmp) throws Exception { dao.eliminar(cmp); }
}
