/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.service;

import com.integrador.dao.PacienteDAO;
import com.integrador.modelo.Paciente;
import com.integrador.util.Validador;
import java.util.List;

/**
 *
 * @author jose2
 */
public class PacienteService {

    private PacienteDAO dao = new PacienteDAO();

    public List<Paciente> listar() throws Exception {
        return dao.listar();
    }

    public Paciente buscarPorDni(String dni) throws Exception {
        return dao.buscarPorDni(dni);
    }

    public void registrar(Paciente p) throws Exception {
        if (!Validador.validarDNI(p.getDni())) {
            throw new Exception("DNI inválido (8 dígitos)");
        }
        if (!Validador.noVacio(p.getNombres())) {
            throw new Exception("Nombres obligatorios");
        }
        if (!Validador.noVacio(p.getApellidos())) {
            throw new Exception("Apellidos obligatorios");
        }
        if (p.getFechaNacimiento() == null) {
            throw new Exception("Fecha de nacimiento obligatoria");
        }
        if (!Validador.validarEmail(p.getEmail())) {
            throw new Exception("Email inválido");
        }
        if (!Validador.validarTelefono(p.getTelefono())) {
            throw new Exception("Teléfono inválido (9 dígitos)");
        }
        if (dao.buscarPorDni(p.getDni()) != null) {
            throw new Exception("Ya existe un paciente con ese DNI");
        }
        dao.crear(p);
    }

    public void actualizar(Paciente p) throws Exception {
        if (!Validador.validarDNI(p.getDni())) {
            throw new Exception("DNI inválido");
        }
        dao.actualizar(p);
    }

    public void eliminar(String dni) throws Exception {
        dao.eliminar(dni);
    }

}
