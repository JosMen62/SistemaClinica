/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.Especialidad;
import com.integrador.modelo.Medico;
import com.integrador.service.EspecialidadService;
import com.integrador.service.MedicoService;
import com.integrador.Vista.MedicoView;
import javax.swing.table.DefaultTableModel;

public class MedicoController {
    private MedicoService medicoService = new MedicoService();
    private EspecialidadService espService = new EspecialidadService();
    private MedicoView view;

    public MedicoController(MedicoView view) {
        this.view = view;
        this.view.getBtnGuardar().addActionListener(e -> guardar());
        this.view.getBtnEditar().addActionListener(e -> editar());
        this.view.getBtnEliminar().addActionListener(e -> eliminar());
        this.view.getBtnLimpiar().addActionListener(e -> limpiar());
        cargarEspecialidades();
        cargarTabla();
    }

    private void cargarEspecialidades() {
        try {
            for (Especialidad e : espService.listar()) {
                view.getCmbEspecialidad().addItem(e.getNombre());
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private Medico obtenerDatos() {
        Medico m = new Medico();
        m.setCmp(view.getTxtCmp().getText().trim().toUpperCase());
        m.setNombres(view.getTxtNombres().getText().trim());
        m.setApellidos(view.getTxtApellidos().getText().trim());
        m.setTelefono(view.getTxtTelefono().getText().trim());
        m.setEmail(view.getTxtEmail().getText().trim());
        String espSel = (String) view.getCmbEspecialidad().getSelectedItem();
        Especialidad esp = new Especialidad();
        esp.setNombre(espSel);
        m.setEspecialidad(esp);
        return m;
    }

    private void guardar() {
        try {
            medicoService.registrar(obtenerDatos());
            view.mostrarMensaje("Médico registrado");
            limpiar(); cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void editar() {
        try {
            medicoService.actualizar(obtenerDatos());
            view.mostrarMensaje("Actualizado");
            cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void eliminar() {
        try {
            String cmp = view.getTxtCmp().getText().trim();
            if (cmp.isEmpty()) { view.mostrarError("Ingrese CMP"); return; }
            medicoService.eliminar(cmp);
            view.mostrarMensaje("Eliminado");
            limpiar(); cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void limpiar() { view.limpiarFormulario(); }

    private void cargarTabla() {
        try {
            DefaultTableModel m = (DefaultTableModel) view.getTblMedicos().getModel();
            m.setRowCount(0);
            for (Medico med : medicoService.listar()) {
                m.addRow(new Object[]{med.getCmp(), med.getNombres(), med.getApellidos(), med.getEspecialidad().getNombre(), med.getTelefono()});
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }
}

