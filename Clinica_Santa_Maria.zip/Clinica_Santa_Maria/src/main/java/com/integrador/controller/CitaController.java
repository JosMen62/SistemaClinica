/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.*;
import com.integrador.service.*;
import com.integrador.Vista.CitaView;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.swing.JOptionPane;

public class CitaController {
    private CitaService citaService = new CitaService();
    private PacienteService pacienteService = new PacienteService();
    private MedicoService medicoService = new MedicoService();
    private EspecialidadService espService = new EspecialidadService();
    private CitaView view;

    public CitaController(CitaView view) {
        this.view = view;
        this.view.getBtnRegistrar().addActionListener(e -> registrar());
        this.view.getBtnCancelar().addActionListener(e -> cancelar());
        this.view.getBtnBuscar().addActionListener(e -> buscar());
        cargarPacientes();
        cargarEspecialidades();
        cargarMedicos();
        cargarTabla();
    }

    private void cargarPacientes() {
        try {
            for (Paciente p : pacienteService.listar()) {
                view.getCmbPaciente().addItem(p.getDni() + " - " + p.getNombreCompleto());
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void cargarEspecialidades() {
        try {
            for (Especialidad e : espService.listar()) {
                view.getCmbEspecialidad().addItem(e.getNombre());
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void cargarMedicos() {
        try {
            for (Medico m : medicoService.listar()) {
                view.getCmbMedico().addItem(m.getCmp() + " - " + m.getNombreCompleto());
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void registrar() {
        try {
            Cita c = new Cita();

            String pacSel = (String) view.getCmbPaciente().getSelectedItem();
            String dni = pacSel.split(" - ")[0];
            c.setPaciente(pacienteService.buscarPorDni(dni));

            String medSel = (String) view.getCmbMedico().getSelectedItem();
            String cmp = medSel.split(" - ")[0];
            Medico m = medicoService.buscarPorCMP(cmp);
            c.setMedico(m);
            c.setEspecialidad(m.getEspecialidad());

            c.setFecha(view.getDateFecha().getDate().toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate());
            c.setHora(LocalTime.parse(view.getTxtHora().getText().trim()));
            c.setObservaciones(view.getTxtObservaciones().getText().trim());

            citaService.registrar(c);
            view.mostrarMensaje("Cita registrada exitosamente");
            cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void cancelar() {
        try {
            int fila = view.getTblCitas().getSelectedRow();
            if (fila < 0) { view.mostrarError("Seleccione una cita"); return; }
            int id = (int) view.getTblCitas().getValueAt(fila, 0);
            int confirm = JOptionPane.showConfirmDialog(view, "¿Cancelar cita #" + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                citaService.cancelar(id);
                view.mostrarMensaje("Cita cancelada");
                cargarTabla();
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void buscar() {
        try {
            LocalDate fecha = view.getDateFecha().getDate().toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            DefaultTableModel m = (DefaultTableModel) view.getTblCitas().getModel();
            m.setRowCount(0);
            for (Cita c : citaService.consultarPorFecha(fecha)) {
                m.addRow(new Object[]{c.getId(), c.getPaciente().getDni(), c.getMedico().getCmp(), c.getEspecialidad().getNombre(), c.getFecha(), c.getHora(), c.getEstado()});
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void cargarTabla() {
        try {
            DefaultTableModel m = (DefaultTableModel) view.getTblCitas().getModel();
            m.setRowCount(0);
            for (Cita c : citaService.listar()) {
                m.addRow(new Object[]{c.getId(), c.getPaciente().getDni(), c.getMedico().getCmp(), c.getEspecialidad().getNombre(), c.getFecha(), c.getHora(), c.getEstado()});
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }
}


