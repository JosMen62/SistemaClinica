/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.Paciente;
import com.integrador.service.PacienteService;
import com.integrador.Vista.PacienteView;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;

public class PacienteController {
    private PacienteService service = new PacienteService();
    private PacienteView view;

    public PacienteController(PacienteView view) {
        this.view = view;
        this.view.getBtnGuardar().addActionListener(e -> guardar());
        this.view.getBtnEditar().addActionListener(e -> editar());
        this.view.getBtnEliminar().addActionListener(e -> eliminar());
        this.view.getBtnLimpiar().addActionListener(e -> limpiar());
        this.view.getBtnBuscar().addActionListener(e -> buscar());
        cargarTabla();
    }

    private Paciente obtenerDatos() {
        Paciente p = new Paciente();
        p.setDni(view.getTxtDni().getText().trim());
        p.setNombres(view.getTxtNombres().getText().trim());
        p.setApellidos(view.getTxtApellidos().getText().trim());
        p.setTelefono(view.getTxtTelefono().getText().trim());
        p.setEmail(view.getTxtEmail().getText().trim());
        p.setDireccion(view.getTxtDireccion().getText().trim());
        if (view.getDateNacimiento().getDate() != null) {
            p.setFechaNacimiento(view.getDateNacimiento().getDate().toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalDate());
        }
        return p;
    }

    private void guardar() {
        try {
            service.registrar(obtenerDatos());
            view.mostrarMensaje("Paciente registrado");
            limpiar(); cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void editar() {
        try {
            service.actualizar(obtenerDatos());
            view.mostrarMensaje("Actualizado");
            cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void eliminar() {
        try {
            String dni = view.getTxtDni().getText().trim();
            if (dni.isEmpty()) { view.mostrarError("Ingrese DNI"); return; }
            service.eliminar(dni);
            view.mostrarMensaje("Eliminado");
            limpiar(); cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void buscar() {
        try {
            String dni = view.getTxtBuscar().getText().trim();
            Paciente p = service.buscarPorDni(dni);
            if (p != null) {
                view.getTxtDni().setText(p.getDni());
                view.getTxtNombres().setText(p.getNombres());
                view.getTxtApellidos().setText(p.getApellidos());
                view.getTxtTelefono().setText(p.getTelefono());
                view.getTxtEmail().setText(p.getEmail());
                view.getTxtDireccion().setText(p.getDireccion());
            } else view.mostrarMensaje("No encontrado");
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void limpiar() { view.limpiarFormulario(); }

    private void cargarTabla() {
        try {
            DefaultTableModel m = (DefaultTableModel) view.getTblPacientes().getModel();
            m.setRowCount(0);
            for (Paciente p : service.listar()) {
                m.addRow(new Object[]{p.getDni(), p.getNombres(), p.getApellidos(), p.getTelefono(), p.getEmail()});
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    
}

