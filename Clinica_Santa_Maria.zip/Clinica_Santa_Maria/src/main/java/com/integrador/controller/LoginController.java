/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.Usuario;
import com.integrador.service.UsuarioService;
import com.integrador.Vista.LoginView;
import com.integrador.Vista.Dashboard;
import javax.swing.JOptionPane;

public class LoginController {
    private UsuarioService service = new UsuarioService();
    private LoginView view;

    public LoginController(LoginView view) {
        this.view = view;
        this.view.getBtnIngresar().addActionListener(e -> iniciarSesion());
        this.view.getBtnSalir().addActionListener(e -> salir());
    }

    private void iniciarSesion() {
        try {
            String username = view.getTxtUsuario().getText().trim();
            String password = new String(view.getTxtPassword().getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Complete todos los campos", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Usuario usuario = service.autenticar(username, password);
            JOptionPane.showMessageDialog(view, "Bienvenido: " + usuario.getUsername() + " (" + usuario.getRol() + ")");
            
            view.dispose();
            Dashboard dashboard = new Dashboard(usuario);
            dashboard.setVisible(true);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error: " + e.getMessage(), "Error de autenticación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void salir() {
        int confirm = JOptionPane.showConfirmDialog(view, "¿Desea salir del sistema?", "Salir", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}
