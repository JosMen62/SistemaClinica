/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.Horario;
import com.integrador.modelo.Medico;
import com.integrador.service.HorarioService;
import com.integrador.service.MedicoService;
import com.integrador.Vista.HorarioView;
import javax.swing.table.DefaultTableModel;
import java.time.LocalTime;
public class HorarioController {
    private HorarioService horarioService = new HorarioService();
    private MedicoService medicoService = new MedicoService();
    private HorarioView view;

    public HorarioController(HorarioView view) {
        this.view = view;
        this.view.getBtnGuardar().addActionListener(e -> guardar());
        this.view.getBtnEliminar().addActionListener(e -> eliminar());
        cargarMedicos();
        cargarTabla();
    }

    private void cargarMedicos() {
        try {
            for (Medico m : medicoService.listar()) {
                view.getCmbMedico().addItem(m.getCmp() + " - " + m.getNombreCompleto());
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void guardar() {
        try {
            Horario h = new Horario();
            String medSel = (String) view.getCmbMedico().getSelectedItem();
            String cmp = medSel.split(" - ")[0];
            Medico m = medicoService.buscarPorCMP(cmp);
            h.setMedico(m);
            h.setDiaSemana((String) view.getCmbDia().getSelectedItem());
            h.setHoraInicio(LocalTime.parse(view.getTxtHoraInicio().getText().trim()));
            h.setHoraFin(LocalTime.parse(view.getTxtHoraFin().getText().trim()));
            h.setDuracionCita(Integer.parseInt(view.getTxtDuracion().getText().trim()));
            h.setCapacidadMaxima(Integer.parseInt(view.getTxtCapacidad().getText().trim()));

            horarioService.registrar(h);
            view.mostrarMensaje("Horario registrado. Capacidad total: " + h.calcularCapacidadTotal() + " citas");
            cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void eliminar() {
        try {
            int fila = view.getTblHorarios().getSelectedRow();
            if (fila < 0) { view.mostrarError("Seleccione fila"); return; }
            int id = (int) view.getTblHorarios().getValueAt(fila, 0);
            horarioService.eliminar(id);
            view.mostrarMensaje("Eliminado");
            cargarTabla();
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }

    private void cargarTabla() {
        try {
            DefaultTableModel m = (DefaultTableModel) view.getTblHorarios().getModel();
            m.setRowCount(0);
            for (Horario h : horarioService.listar()) {
                m.addRow(new Object[]{h.getId(), h.getMedico().getCmp(), h.getDiaSemana(), h.getHoraInicio(), h.getHoraFin(), h.getDuracionCita(), h.getCapacidadMaxima(), h.calcularCapacidadTotal()});
            }
        } catch (Exception e) { view.mostrarError(e.getMessage()); }
    }
}

