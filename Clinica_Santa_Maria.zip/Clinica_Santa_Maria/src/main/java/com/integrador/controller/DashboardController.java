/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.Usuario;
import com.integrador.Vista.*;
import javax.swing.JOptionPane;

public class DashboardController {
    private Usuario usuario;
    private Dashboard view;

    public DashboardController(Dashboard view, Usuario usuario) {
        this.view = view;
        this.usuario = usuario;
        this.view.getBtnPacientes().addActionListener(e -> new PacienteController(new PacienteView()));
        this.view.getBtnMedicos().addActionListener(e -> new MedicoController(new MedicoView()));
        this.view.getBtnCitas().addActionListener(e -> new CitaController(new CitaView()));
        this.view.getBtnEspecialidades().addActionListener(e -> new EspecialidadController(new EspecialidadView()));
        this.view.getBtnHorarios().addActionListener(e -> new HorarioController(new HorarioView()));
        this.view.getBtnCerrarSesion().addActionListener(e -> cerrarSesion());
    }

    private void cerrarSesion() {
        int confirm = JOptionPane.showConfirmDialog(view, "¿Cerrar sesión?", "Salir", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            view.dispose();
            LoginView login = new LoginView();
            new LoginController(login);
            login.setVisible(true);
        }
    }
}

