/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.controller;

import com.integrador.modelo.Especialidad;
import com.integrador.service.EspecialidadService;
import com.integrador.Vista.EspecialidadView;
import javax.swing.table.DefaultTableModel;

public class EspecialidadController {
    private EspecialidadService service = new EspecialidadService();
    private EspecialidadView view;

    public EspecialidadController(EspecialidadView view) {
        this.view = view;
        this.view.getBtnGuardar().addActionListener(e -> guardar());
        this.view.getBtnEditar().addActionListener(e -> editar());
        this.view.getBtnEliminar().addActionListener(e -> eliminar());
        this.view.getBtnLimpiar().addActionListener(e -> limpiar());
        cargarTabla();
    }

    private void guardar() {
        try {
            Especialidad e = new Especialidad();
            e.setNombre(view.getTxtNombre().getText().trim());
            e.setDescripcion(view.getTxtDescripcion().getText().trim());
            service.registrar(e);
            view.mostrarMensaje("Especialidad registrada");
            limpiar(); cargarTabla();
        } catch (Exception ex) { view.mostrarError(ex.getMessage()); }
    }

    private void editar() {
        try {
            int fila = view.getTblEspecialidades().getSelectedRow();
            if (fila < 0) { view.mostrarError("Seleccione una fila"); return; }
            int id = (int) view.getTblEspecialidades().getValueAt(fila, 0);
            Especialidad e = new Especialidad();
            e.setId(id);
            e.setNombre(view.getTxtNombre().getText().trim());
            e.setDescripcion(view.getTxtDescripcion().getText().trim());
            service.actualizar(e);
            view.mostrarMensaje("Actualizado");
            limpiar(); cargarTabla();
        } catch (Exception ex) { view.mostrarError(ex.getMessage()); }
    }

    private void eliminar() {
        try {
            int fila = view.getTblEspecialidades().getSelectedRow();
            if (fila < 0) { view.mostrarError("Seleccione una fila"); return; }
            int id = (int) view.getTblEspecialidades().getValueAt(fila, 0);
            service.eliminar(id);
            view.mostrarMensaje("Eliminado");
            cargarTabla();
        } catch (Exception ex) { view.mostrarError(ex.getMessage()); }
    }

    private void limpiar() { view.limpiarFormulario(); }

    private void cargarTabla() {
        try {
            DefaultTableModel m = (DefaultTableModel) view.getTblEspecialidades().getModel();
            m.setRowCount(0);
            for (Especialidad e : service.listar()) {
                m.addRow(new Object[]{e.getId(), e.getNombre(), e.getDescripcion()});
            }
        } catch (Exception ex) { view.mostrarError(ex.getMessage()); }
    }
}

