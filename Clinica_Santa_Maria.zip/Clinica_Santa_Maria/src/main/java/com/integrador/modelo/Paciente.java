/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.modelo;

import java.time.LocalDate;

/**
 *
 * @author jose2
 */
public class Paciente {
    private String dni; // PK
    private String nombres, apellidos, telefono, email, direccion;
    private LocalDate fechaNacimiento;
    private boolean estado;

    public Paciente() {}

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public String getNombres() { return nombres; }
    public void setNombres(String n) { this.nombres = n; }
    public String getApellidos() { return apellidos; }
    public void setApellidos(String a) { this.apellidos = a; }
    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate f) { this.fechaNacimiento = f; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String t) { this.telefono = t; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String d) { this.direccion = d; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean e) { this.estado = e; }

    public String getNombreCompleto() { return nombres + " " + apellidos; }

}

