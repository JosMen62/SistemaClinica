/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.modelo;

import java.time.Duration;
import java.time.LocalTime;



public class Horario {
    private int id;
    private Medico medico;
    private String diaSemana;
    private LocalTime horaInicio, horaFin;
    private int duracionCita;
    private int capacidadMaxima;
    private boolean estado;

    public Horario() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Medico getMedico() { return medico; }
    public void setMedico(Medico m) { this.medico = m; }
    public String getDiaSemana() { return diaSemana; }
    public void setDiaSemana(String d) { this.diaSemana = d; }
    public LocalTime getHoraInicio() { return horaInicio; }
    public void setHoraInicio(LocalTime h) { this.horaInicio = h; }
    public LocalTime getHoraFin() { return horaFin; }
    public void setHoraFin(LocalTime h) { this.horaFin = h; }
    public int getDuracionCita() { return duracionCita; }
    public void setDuracionCita(int d) { this.duracionCita = d; }
    public int getCapacidadMaxima() { return capacidadMaxima; }
    public void setCapacidadMaxima(int c) { this.capacidadMaxima = c; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean e) { this.estado = e; }

    public int calcularCapacidadTotal() {
        long mins = Duration.between(horaInicio, horaFin).toMinutes();
        return (int) (mins / duracionCita) * capacidadMaxima;
    }
}

