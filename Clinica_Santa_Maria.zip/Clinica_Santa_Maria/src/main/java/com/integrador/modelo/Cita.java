/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class Cita {
    private int id;
    private Paciente paciente;
    private Medico medico;
    private Especialidad especialidad;
    private LocalDate fecha;
    private LocalTime hora;
    private String estado;
    private String observaciones;

    public Cita() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Paciente getPaciente() { return paciente; }
    public void setPaciente(Paciente p) { this.paciente = p; }
    public Medico getMedico() { return medico; }
    public void setMedico(Medico m) { this.medico = m; }
    public Especialidad getEspecialidad() { return especialidad; }
    public void setEspecialidad(Especialidad e) { this.especialidad = e; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate f) { this.fecha = f; }
    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime h) { this.hora = h; }
    public String getEstado() { return estado; }
    public void setEstado(String e) { this.estado = e; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String o) { this.observaciones = o; }

}

