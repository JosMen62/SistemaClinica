/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.modelo;


public class Medico {
    private String cmp; // PK
    private String nombres, apellidos, telefono, email;
    private Especialidad especialidad;
    private boolean estado;

    public Medico() {}

    public String getCmp() { return cmp; }
    public void setCmp(String cmp) { this.cmp = cmp; }
    public String getNombres() { return nombres; }
    public void setNombres(String n) { this.nombres = n; }
    public String getApellidos() { return apellidos; }
    public void setApellidos(String a) { this.apellidos = a; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String t) { this.telefono = t; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public Especialidad getEspecialidad() { return especialidad; }
    public void setEspecialidad(Especialidad e) { this.especialidad = e; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean e) { this.estado = e; }

    public String getNombreCompleto() { return "Dr. " + nombres + " " + apellidos; }

}

