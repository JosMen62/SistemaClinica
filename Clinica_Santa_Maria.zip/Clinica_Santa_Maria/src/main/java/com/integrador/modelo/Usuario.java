/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.integrador.modelo;

import java.time.LocalDateTime;

/**
 *
 * @author jose2
 */
public class Usuario {

    private int id;
    private String username;
    private String passwordHash;
    private String rol;
    private boolean estado;
    private LocalDateTime fechaCreacion;

    public Usuario() {
    }

    public Usuario(int id, String username, String passwordHash,
            String rol, boolean estado) {
        this.id = id;
        this.username = username;
        this.passwordHash = passwordHash;
        this.rol = rol;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public boolean esAdministrador() {
        return "ADMIN".equals(rol);
    }

    public boolean esRecepcionista() {
        return "RECEP".equals(rol);
    }

    public boolean esMedico() {
        return "MEDICO".equals(rol);
    }
}
