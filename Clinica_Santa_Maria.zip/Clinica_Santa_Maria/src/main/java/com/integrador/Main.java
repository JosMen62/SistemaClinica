/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.integrador;

import com.integrador.Vista.LoginView;
import com.integrador.controller.LoginController;

/**
 *
 * @author jose2
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginView login = new LoginView();
        new LoginController(login);
        login.setVisible(true);
    }
    
}
