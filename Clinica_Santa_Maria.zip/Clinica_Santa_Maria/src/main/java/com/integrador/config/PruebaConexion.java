package com.integrador.config;

import com.integrador.config.ConexionMySQL;
import java.sql.Connection;

/**
 * Clase temporal SOLO para probar la conexión a MySQL.
 * ¡BORRAR DESPUÉS de verificar que funciona!
 */
public class PruebaConexion {
    
    public static void main(String[] args) {
        System.out.println("=== INICIANDO PRUEBA DE CONEXION ===");
        
        try {
            // 1. Obtener la conexión
            Connection conexion = ConexionMySQL.getInstancia().getConexion();
            
            // 2. Verificar si la conexión es válida
            if (conexion != null && !conexion.isClosed()) {
                System.out.println(" CONEXION EXITOSA!");
                System.out.println(" Base de datos conectada: " + conexion.getCatalog());
                System.out.println(" URL: " + conexion.getMetaData().getURL());
                System.out.println(" Usuario: " + conexion.getMetaData().getUserName());
                System.out.println(" Version MySQL: " + conexion.getMetaData().getDatabaseProductVersion());
            } else {
                System.out.println("❌ La conexion es nula o está cerrada");
            }
            
        } catch (Exception e) {
            System.out.println("❌ ERROR DE CONEXIÓN:");
            System.out.println(" Mensaje: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("=== FIN DE LA PRUEBA ===");
    }
}